package com.application.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.Entity.Position;
import com.application.repository.PositionRepository;
import com.application.service.PositionService;


@Service
public class PositionServiceImpl implements PositionService{

	@Autowired
	private PositionRepository positionRepository;
	//查询所有的岗位
	public List<Position> queryAll() {
		
		return positionRepository.findAll();
	}
	
	//保存岗位
	public boolean addPosition(String name,String coding) {
		
		if(positionRepository.queryByCoding(coding).size()==0&&positionRepository.queryByName(name).size()==0)
		{
			Position position=new Position();
			position.setCoding(coding);
			position.setPositionName(name);
			position.setUserNumber(0);
			Date date=new Date();
			SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-mm-dd");
			position.setCreateTime(simpleDateFormat.format(date));
			positionRepository.saveAndFlush(position);
			return true;
			
		}
		return false;
	}

	public List<Position> queryByName(String name) {
		
		return positionRepository.queryByName(name);
	}

	public List<Position> queryByCoding(String coding) {
		// TODO Auto-generated method stub
		return positionRepository.queryByCoding(coding);
	}

	public boolean deleteById(int id) {
		if(positionRepository.findById(id).get().getUserNumber()>0)
		{
			return false;
		}
		else
		{
			positionRepository.deleteById(id);
			return true;
		}
		
	}

	public Position queryById(int id) {
		
		return positionRepository.findById(id).get();
	}

	public boolean editPosition(int id, String name, String coding) {
		if(positionRepository.queryByCoding(coding).size()==0&&positionRepository.queryByName(name).size()==0)
		{
			Position position=positionRepository.findById(id).get();
			position.setCoding(coding);
			position.setPositionName(name);
			positionRepository.saveAndFlush(position);
			return true;
		}
		return false;
	}
	
	

	


	
	
	
	

}



