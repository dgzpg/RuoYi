package com.application.controller;

import java.util.List;
import java.util.Map;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.application.Entity.Position;
import com.application.service.PositionService;

@Controller
public class PositionManagerController {

	@Autowired
	private PositionService positionService;
	
	//添加岗位跳转页面控制
	@GetMapping("/addPosition")
	public String addPosition()
	{
		return "/addPosition";
	}
	
	//添加岗位控制
	@PostMapping("/getAddPosition")

	public String getAddPosition(@RequestParam("name")String name,@RequestParam("coding")String coding,Model model,Map<String , Object>map)
	{
		if(positionService.addPosition(name, coding)==false)
		{
			map.put("msg", "添加失败！");
			//return name+coding;
			return "/addPosition";
		}
		else
		{
			return "redirect:mainPage";
		}
		
	}
	
	@GetMapping("/searchPosition")
	public String searchPosition(@RequestParam("name")String name, Model model)
	{
		List<Position>positions=positionService.queryByName(name);
		for(Position position : positionService.queryByCoding(name))
		{
			positions.add(position);
		}
		model.addAttribute("positions", positions);
		
		return "mainPage";
	}
	
	@GetMapping("/deletePosition")
	public String deletePosition(@PathParam("id")int id,Map<String , Object>map)
	{
		if(positionService.deleteById(id)==false)
		{
			map.put("msg", "删除失败！");
		}
		return "redirect:/mainPage";
		
		
	}
	
	//修改跳转控制
	@GetMapping("/edit")
	public String edit(@PathParam("id")int id,Model model)
	{
		Position position=positionService.queryById(id);
		model.addAttribute("position",position);
		return "/editPosition";
		
	}
	
	@PostMapping("/getEdit")
	public String getEdit(@PathParam("id")int id,@RequestParam("name")String name,@RequestParam("Coding")String Coding,Model model,Map<String , Object>map)
	{
		
		if(positionService.editPosition(id, name, Coding))
		{
			return "redirect:mainPage";
		}
		else
		{
			Position position=positionService.queryById(id);
			model.addAttribute("position", position);
			map.put("msg", "修改失败！");
			return "/editPosition";
		}
			
		
	}
}
