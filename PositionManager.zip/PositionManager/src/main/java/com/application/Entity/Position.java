package com.application.Entity;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="position")
public class Position {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;

	//岗位编码
	private String coding;
	
	//岗位名称
	private String positionName;
	
	//岗位人数
	private int userNumber;
	
	//创建时间
	private String createTime;

	public Position() {
		super();
	}

	public Position(int id, String coding, String positionName, int userNumber, String createTime) {
		super();
		this.id = id;
		this.coding = coding;
		this.positionName = positionName;
		this.userNumber = userNumber;
		this.createTime = createTime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCoding() {
		return coding;
	}

	public void setCoding(String coding) {
		this.coding = coding;
	}

	public String getPositionName() {
		return positionName;
	}

	public void setPositionName(String positionName) {
		this.positionName = positionName;
	}

	public int getUserNumber() {
		return userNumber;
	}

	public void setUserNumber(int userNumber) {
		this.userNumber = userNumber;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	@Override
	public String toString() {
		return "Position [id=" + id + ", coding=" + coding + ", positionName=" + positionName + ", userNumber="
				+ userNumber + ", createTime=" + createTime + "]";
	}
	
	
	
	
	
	
	
	
	
}
