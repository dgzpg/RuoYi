package com.application.serviceImpl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;
import org.springframework.web.multipart.MultipartFile;

import com.application.Entity.User;
import com.application.Util.FileUtil;
import com.application.repository.UserRepository;
import com.application.service.UserService;




@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userRepository;
	
	/*
	 * 根据账号和密码来进行查询，验证是否存在该对象
	 * 用于登录验证和主页服务需要
	 */
	public User queryForLogin(String  countId,String password) {
		
		
		return this.userRepository.queryByName(countId, password);
	
	}
	
	public User queryForRegistry(String countId, String password) {
		
		if(userRepository.queryByCountId(countId)==null)
		{
			User user=new User();
			user.setCountId(countId);
			user.setPassword(password);
			return user;
		}
		return null;
	}
	
	
	
	/*
	 * 根据用户账号来查询
	 * 用于注册验证服务需要
	 */
	public User queryByCountId(String  countId) {
		
		return userRepository.queryByCountId(countId);
	}


	/*
	 * 保存一个账号，用于注册服务需要
	 * 
	 */
	public void saveUser(User user) {
		// TODO Auto-generated method stub
		userRepository.saveAndFlush(user);
		
	}

	public List<User> getAll() {
		
		return userRepository.findAll();
	}

	/*public User queryById(int id) {
		

		return userRepository.queryById(id);
	}
*/
	

	/*public void updateUser(int id,String sex, String telephone, String email, String role, String position,
			String personalDescription, String userName) {
		Optional<User>optional=userRepository.findById(id);
		User user=optional.get();
		user.setSex(sex);
		user.setTelephone(telephone);
		user.setEmail(email);
		user.setRole(role);
		user.setPosition(position);
		user.setPersonalDescription(personalDescription);
		user.setUserName(userName);
		userRepository.saveAndFlush(user);
		
		
	}*/

	public void deleteUser(int id) {
		
		userRepository.deleteById(id);
	}

	public List<User> queryUserByUserName(String userName) {
		List<User> users=userRepository.queryByUserName(userName);
		return users;
	}

	public void savePicture(String countId,MultipartFile file) {
		
		if(!file.isEmpty())
		{
			//获取文件名称，包含后缀
			String fileName=file.getOriginalFilename();
			
			//存放在这个路径下，该路径在工程的static文件下
			//通过浏览器输入本地服务器地址加文件后缀名就可以访问该文件
			String path=ClassUtils.getDefaultClassLoader().getResource("").getPath()+"static/";
			
			try {
				FileUtil.fileupload(file.getBytes(), path, fileName);
			} catch (Exception e) {
				// TODO: handle exception
			}
			User user=userRepository.queryByCountId(countId);
			Optional<User> optional=userRepository.findById(user.getId());
			User user2=optional.get();
			user2.setPath(fileName);
			
			
			
		}
		
	}

	public void updateUser(int id, String role, String position, String department) {
		Optional<User>optional=userRepository.findById(id);
		User user=optional.get();
		user.setRole(role);
		user.setPosition(position);
		user.setDepartment(department);
		userRepository.saveAndFlush(user);
	}



	
	
	
	

}






/*if(!file.isEmpty())
{
	//获取文件名称，包含后缀
	String fileName=file.getOriginalFilename();
	
	//存放在这个路径下，该路径在工程的static文件下
	//通过浏览器输入本地服务器地址加文件后缀名就可以访问该文件
	String path=ClassUtils.getDefaultClassLoader().getResource("").getPath()+"static/";
	
	try {
		FileUtil.fileupload(file.getBytes(), path, fileName);
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	Picture pic=new Picture();
	pic.setPath("http://localhost:8010/"+fileName);
	
	
}*/
