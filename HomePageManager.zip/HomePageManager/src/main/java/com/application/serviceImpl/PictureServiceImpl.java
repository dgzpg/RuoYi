package com.application.serviceImpl;

public class PictureServiceImpl {
	

}
