package com.application.service;

import java.util.List;

import com.application.Entity.FirstMenu;

public interface MenuService {
	
	public List<FirstMenu> queryAllFirstMenu();
	
	


}
