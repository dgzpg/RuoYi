package com.application.controller;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;

import com.application.Entity.User;
import com.application.repository.UserRepository;
import com.application.service.UserService;

@Controller

public class UserManegerPage {

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepository;
	
	//主页面
	@GetMapping("/userMainPage")
	public String getFirst(Model model)
	{
		List<User> users=new ArrayList<User>();
		users=userService.getAll();
		model.addAttribute("users", users);
		return "/users/user";
	}
	
	//添加用户
	@GetMapping("/addUser")
	public String AddUser( String sex)
	{
		
		return "/users/addUser";
	}

	@PostMapping("/getAddUser")
	public String getUser( )
	{
		ServletRequestAttributes servletRequestAttributes=(ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
		HttpServletRequest request=servletRequestAttributes.getRequest();
		User user=new User();
		user.setCountId(request.getParameter("countId"));
		user.setRole(request.getParameter("role"));
		user.setPosition(request.getParameter("position"));
		Date date=new Date();
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
		user.setRegistrastionDate(simpleDateFormat.format(date));
		user.setDepartment(request.getParameter("department"));
		userService.saveUser(user);
		return "redirect:/userMainPage";
	}
	
	
	//删除用户
	@GetMapping("/deleteUser")
	public String DeleteUser(@RequestParam("id") int id)
	{
		userService.deleteUser(id);
		return "redirect:/userMainPage";
	}
	
	
	
	//修改用户
	@GetMapping("/edit") 

	public String  Edit(@PathParam("countId")String countId,Model model)
	{		
		User user=userService.queryByCountId(countId);
		model.addAttribute("user", user);
		return "/users/editUser";
	}
	
	
	@PostMapping("/getEditUser")

	public String getEdit(@PathParam("id")int id)
	{
		ServletRequestAttributes servletRequestAttributes=(ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
		HttpServletRequest request=servletRequestAttributes.getRequest();
		
		String role=request.getParameter("role");
		String position=request.getParameter("position");
		String department=request.getParameter("department");
		userService.updateUser(id, role, position,department);
		
		return "redirect:/userMainPage";
	}
	
	
	//修改密码
	@GetMapping("/changePassword")
    public String 	ChangePassword(@PathParam ("countId")String countId,Model model)
    {
		User user=userService.queryByCountId(countId);
		model.addAttribute("user", user);
    	return "main/editPassword";
    }
	
	
	@PostMapping("/getEditPassword")
	public String getChangePassword(@PathParam("countId")String countId,@RequestParam("newpassword")String newpassword,@RequestParam("newpassword2")String newpassword2,Model model,Map<String , Object> map)
	{
		User user=userService.queryByCountId(countId);
		if(newpassword.equals(newpassword2)==false)
		{
			map.put("msg","前后密码不一致！");
			
			model.addAttribute("user", user);
			return "main/editPassword";
		}
		Optional<User>optional=userRepository.findById(user.getId());
		User user2=optional.get();
		user2.setPassword(newpassword);
		userRepository.saveAndFlush(user2);
		model.addAttribute("user", user);
		return "/main/userInformation";
	}
	
	
	@GetMapping("/editInformation")
	public String editInformation(@PathParam("countId")String countId,Model model)
	{
		User user=userService.queryByCountId(countId);
		model.addAttribute("user", user);
		return "main/editInformation";
	}
	
	@GetMapping("/getEditInformation")

	public String getEditInformation(@PathParam("countId")String countId,Model model)
	{
		ServletRequestAttributes servletRequestAttributes=(ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
		HttpServletRequest request=servletRequestAttributes.getRequest();
		String userName=request.getParameter("userName");
		String sex=request.getParameter("sex");
		String telephone=request.getParameter("telephone");
		String personalDescription=request.getParameter("personalDescription");
		String email=request.getParameter("email");
		
		Optional<User>optional=userRepository.findById(userService.queryByCountId(countId).getId());
		User user=optional.get();
		user.setUserName(userName);
		user.setSex(sex);
		user.setTelephone(telephone);
		user.setPersonalDescription(personalDescription);
		user.setEmail(email);
		userRepository.saveAndFlush(user);
		model.addAttribute("user",user);
		return "main/userInformation";
		
	}
	
	/*
	 * 
	 * 查找用户，根据用户名或者账号进行查找
	 *name表示用户名或者账号
	 *
	 */
	@GetMapping("/searchUser")
	public String getSearchUser(@RequestParam("name")String name,Model model)
	{
		//通过账号查找
		User user=userService.queryByCountId(name);
		List<User> users=userService.queryUserByUserName(name);
		if(user!=null)
		{
			users.add(user);
		}
		model.addAttribute("users", users);
		return "users/user";
	}
	
	
	
	/**
	 * 获取个人信息请求，跳转至个人信息页面
	 * 
	 */
		@GetMapping("/information")
		public String getInformation(@PathParam("countId")  String countId,Model model)
		{
			User user=new User();
			user=userService.queryByCountId(countId);
			model.addAttribute("user", user);
			
			return "main/userInformation";
		}
		
		
		/*
		 * 修改用户的图片
		 * 
		 */
		
		@GetMapping("/changePicture")
		public String changePicture(@PathParam("countId")String countId,Model model)
		{
			User user=userService.queryByCountId(countId);
			model.addAttribute("user", user);
			return "users/editPicture";
		}
		
		@GetMapping("/getChangePicture")
		public String  getChangePicture(@PathParam("countId")String countId,@RequestParam("file")MultipartFile file)
		{
			userService.savePicture(countId, file);
			return "";
		}
}
