package com.application.controller;

import java.util.List;
import java.util.Map;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import com.application.Entity.FirstMenu;
import com.application.Entity.User;
import com.application.repository.FirstMenuRepository;
import com.application.service.UserService;


@Controller
public class HomePageController {

	

	@Autowired
	private FirstMenuRepository firstMenuRepository;
	
	@Autowired
	private UserService userService;
	
	
	
	
	
	
	
	
	//进入主页面，获取登录账号的信息，获取菜单信息
	@GetMapping("/mainPage")
	public String  getMainPage(@PathParam("countId") String countId,Model model)
	{
		System.out.println("countId:"+countId);
		
		User user=userService.queryByCountId(countId);
		List<FirstMenu> menus=firstMenuRepository.findAll();
		model.addAttribute("user", user);
		model.addAttribute("menus", menus);
		return "main/index";
	}
	

}
