package com.application.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.application.Entity.User;
import com.application.service.UserService;

//用户登录控制

@Controller
public class UserLoginController {
	
	@Autowired
	private UserService userService;
	@GetMapping("/login")
	public String  getAdmin(@RequestParam("countId")String  countId,@RequestParam("password")String password,RedirectAttributes redirectAttributes,Map<String ,Object> map)
	{
		
		User admins=userService.queryForLogin(countId, password);
		if(admins!=null)
		{
			
			redirectAttributes.addAttribute("countId", countId);
			return "redirect:/mainPage";
		}
		else
		{
			map.put("msg", "用户名密码错误");
			return "main/login";
		}
		
	}
	
	@GetMapping("/log")
	public String getLog()
	{
		return "main/login";
	}
	
	
	
}
