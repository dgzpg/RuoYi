package com.application.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.application.Entity.Role;
import com.application.repostiy.RoleResposty;
import com.application.service.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleResposty roleResposty;
	
	
	//根据角色名来查询角色
	public List<Role> queryByRoleName(String roleName) {
		
		List<Role> roles=roleResposty.queryByRoleName(roleName);
		return roles;
	}
	///根据角色id来查找
	public Role queryById(int id) {
	
		return roleResposty.findById(id).get();
	}
	

	//查询所有角色
	public List<Role> queryAll() {
		
		return roleResposty.findAll();
	}
	
	//添加角色
	public void addRole(Role role)
	{
		roleResposty.saveAndFlush(role);
	}
	
	//删除角色
	public void deleteRole(int id)
	{
		
		roleResposty.deleteById(id);
	}

	public void editRole(int id,String roleName,int power) {
		Optional<Role> optional=roleResposty.findById(id);
		Role role=optional.get();
		role.setPower(power);
		roleResposty.saveAndFlush(role);
		
	}

	public List<Role> queryByPower(int power) {
	
		return roleResposty.queryByPower(power);
	}

	
	
	
	
}
