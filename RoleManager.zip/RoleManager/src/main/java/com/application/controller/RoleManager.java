package com.application.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.application.Entity.Role;
import com.application.service.RoleService;

@Controller
public class RoleManager {
	
	@Autowired
	private RoleService roleService;
	
	//此处的name代表角色名和角色的权值
		@GetMapping("/getRoles")

		public String getRole(@RequestParam("name") String name,Model model)
		{
			if(name=="")
			{
				return "redirect:/mainPage";
			}
			
			List<Role> roles=roleService.queryByRoleName(name);
			Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");  
			if(pattern.matcher(name).matches())
			{
					int power=Integer.valueOf(name);
					for(Role role : roleService.queryByPower(power))
					{
						roles.add(role);
					}
			}
			model.addAttribute("roles", roles);
			return "roles/role";
		}
		
		//添加角色页面跳转
		@GetMapping("/addRole")
		public String addRole()
		{
			return "roles/addRole";
		}
		
		//实现添加角色
		@PostMapping("/getAddRole")
		public String getAddRole(@RequestParam("roleName")String roleName,@RequestParam("power") String power)
		{
			int pow=Integer.valueOf(power);
			Role role=new Role();
			Date date=new Date();
			SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-mm-dd");
			role.setRegistrionDate(simpleDateFormat.format(date));
			role.setPower(pow);
			role.setRoleName(roleName);
			roleService.addRole(role);
			
			return "redirect:/mainPage";
		}
		
		//修改跳转控制
		@GetMapping("/edit")
		public String edit(@PathParam("id")int id,Model model)
		{
			Role role=new Role();
			role=roleService.queryById(id);
			model.addAttribute("role", role);
			return "roles/editRole";
		}
		
		//修改控制
		@PostMapping("/getEdit")
		
		public String getEdit(@PathParam("id")int id,@RequestParam("Power")String Power,@RequestParam("roleName")String roleName)
		{
			int power=Integer.valueOf(Power);
			roleService.editRole(id, roleName,power);
			return "redirect:/mainPage";
		}
		
		
		
		@GetMapping("/deleteRole")
		public String deleteRole(@PathParam("id")int id)
		{
			roleService.deleteRole(id);
			return "redirect:/mainPage";
		}
		
		
		

}
