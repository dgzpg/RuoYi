package com.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.application.Entity.Department;
import com.application.service.DepartmentService;

@Controller
public class MainPageController {
	
	@Autowired
	private DepartmentService departmentService;
	@GetMapping("/mainPage")
	public String mainPage(Model model)
	{
		List<Department>departments=departmentService.queryAll();
		model.addAttribute("departments", departments);
		return "departments/department";
	}

}
